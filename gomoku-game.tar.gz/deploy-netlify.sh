#!/bin/bash

# 使用 Netlify 部署脚本

echo "开始部署到 Netlify..."

# 检查是否安装了 netlify-cli
if ! command -v netlify &> /dev/null; then
    echo "正在安装 Netlify CLI..."
    npm install -g netlify-cli
fi

# 部署到 Netlify
netlify deploy --prod --dir=. --site=gomoku-game-cnb

echo "部署完成！访问上面的链接即可玩游戏。"
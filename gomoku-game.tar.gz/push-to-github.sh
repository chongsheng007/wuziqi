#!/bin/bash

# 将代码推送到 GitHub 的脚本
# 请先在 GitHub 上创建名为 'wuziqi-cnb' 的仓库

echo "正在将代码推送到 GitHub..."

# 删除当前的 CNB 远程（如果存在）
git remote remove origin 2>/dev/null

# 添加 GitHub 远程（请替换为你的 GitHub 用户名）
# 示例：git remote add origin https://github.com/你的用户名/wuziqi-cnb.git
git remote add origin https://github.com/863ailab/wuziqi-cnb.git

# 推送到 GitHub
git push -u origin main

echo "推送完成！现在可以访问 GitHub 查看仓库了。"
# CLAUDE.md

## 项目概述

这是一个基于 HTML5 Canvas 的五子棋游戏项目，支持双人对战、悔棋、游戏统计等功能。项目部署在 CNB.cool 平台，通过 GitHub Pages 实现在线访问。

## 环境配置

- **平台**: CNB.cool (https://cnb.cool)
- **部署方式**: GitHub Pages
- **技术栈**: HTML5 + CSS3 + JavaScript (ES6+)
- **用户信息**:
  - 用户名: heidao
  - 昵称: 黑岛
  - 组织: 863ailab (可选)

## 项目结构

```
gomoku-cnb/
├── index.html          # 游戏主文件
├── assets/             # 静态资源
│   ├── css/           # 样式文件
│   │   └── style.css  # 主样式
│   ├── js/            # JavaScript文件
│   │   └── game.js    # 游戏逻辑
│   └── images/        # 图片资源
├── README.md          # 项目说明
├── CLAUDE.md          # 本文件
└── .gitignore         # Git忽略文件
```

## 核心功能

### 游戏功能
- 15×15 标准五子棋棋盘
- 黑白双方轮流落子
- 五子连珠胜负判断（横、竖、斜）
- 悔棋功能（游戏未结束时）
- 重新开始功能
- 游戏时间和步数统计
- 落子历史记录

### 界面特性
- 响应式设计，适配移动端
- 精美的渐变色背景
- 最后一手标记（红点）
- 音效系统（可开关）
- 平滑的动画效果

## 部署信息

### 仓库地址
- 组织仓库: `https://cnb.cool/863ailab/gomoku-cnb`
- 个人仓库: `https://cnb.cool/heidao/gomoku-cnb`

### 访问地址
部署成功后可通过以下地址访问：
- `https://863ailab.cnb.cool/gomoku-cnb` (组织仓库)
- `https://heidao.cnb.cool/gomoku-cnb` (个人仓库)

## Git 配置

```bash
# 本地配置
git config --local user.name "黑岛"
git config --local user.email "heidao@cnb.cool"

# 远程仓库
git remote add origin https://cnb.cool/863ailab/gomoku-cnb
```

## 开发说明

### 修改游戏逻辑
主要游戏逻辑在 `assets/js/game.js` 文件中：
- `Game` 对象：管理游戏状态
- `drawBoard()`: 绘制棋盘
- `makeMove()`: 处理落子
- `checkWin()`: 判断胜负

### 修改界面样式
样式文件在 `assets/css/style.css` 中：
- 响应式断点：768px
- 主题色：渐变紫蓝色
- 动画效果：CSS transitions

## 版本管理

采用语义化版本控制：
- 当前版本: v1.0.0
- 版本格式: vMAJOR.MINOR.PATCH

## 常见问题

### CNB.cool 平台注意事项
1. 仓库 URL 不带 `.git` 后缀
2. 确认仓库归属（个人或组织）
3. GitHub Pages 需要启用
4. 默认分支必须为 `main`

### 游戏相关问题
1. 确保使用现代浏览器
2. Canvas 需要 HTML5 支持
3. 移动端触摸需要适配

## 扩展计划

- [ ] 添加 AI 对战模式
- [ ] 实现在线对战功能
- [ ] 支持棋谱保存和加载
- [ ] 添加多种主题皮肤
- [ ] 实现语音聊天功能

---

## 更新日志

### v1.0.0 (2025-12-04)
- ✅ 完整的五子棋游戏实现
- ✅ 响应式界面设计
- ✅ CNB.cool 平台部署配置
- ✅ GitHub Pages 在线访问支持